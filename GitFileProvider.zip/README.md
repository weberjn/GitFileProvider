# GitFileProvider

This is a JSPWiki [http://jspwiki.apache.org/] PageProvider that uses Git for its page and attachment history.

It is based on JGit [https://eclipse.org/jgit/].
